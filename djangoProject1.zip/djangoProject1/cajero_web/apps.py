from django.apps import AppConfig


class CajeroWebConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cajero_web'
